# Lecture Note PDF Chatbot - Java RAG Project

This is a Java/Spring Boot Retrieval-Augmented Generation project for chatting with academic PDFs such as lecture notes, textbooks, and assignments.

This version is configured for **Windows without Docker**.

## What It Uses

- Java 17
- Spring Boot
- Apache PDFBox for PDF text extraction
- ChromaDB running locally through Python
- Ollama for local LLM mode without an OpenAI key
- Optional OpenAI mode if you have an API key

## Important

You do **not** need Docker for this project.

ChromaDB is started with Python:

```powershell
.\.venv\Scripts\chroma.exe run --path .\chroma_db --host 127.0.0.1 --port 8000
```

The Java app connects to:

```text
http://127.0.0.1:8000
```

## Project Folder

The commands below assume your project is here:

```text
C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya
```

If your folder is different, replace the path in the `cd` commands.

## 1. Install Java 17

Open PowerShell and run:

```powershell
winget install EclipseAdoptium.Temurin.17.JDK
```

Close PowerShell, reopen it, then verify:

```powershell
java -version
```

## 2. Install Python 3.11

Run:

```powershell
winget install Python.Python.3.11
```

Close PowerShell, reopen it, then verify:

```powershell
py -0p
```

You should see Python 3.11 listed.

## 3. Go To The Project Folder

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
```

## 4. Download Maven Locally

These commands install Maven inside the project folder, so global `mvn` is not required.

```powershell
$MavenVersion = "3.9.16"
$ToolsDir = ".\.tools"
$MavenZip = "$ToolsDir\apache-maven-$MavenVersion-bin.zip"
$MavenUrl = "https://dlcdn.apache.org/maven/maven-3/$MavenVersion/binaries/apache-maven-$MavenVersion-bin.zip"
New-Item -ItemType Directory -Force -Path $ToolsDir
Invoke-WebRequest -Uri $MavenUrl -OutFile $MavenZip
Expand-Archive -Path $MavenZip -DestinationPath $ToolsDir -Force
```

Verify local Maven:

```powershell
& ".\.tools\apache-maven-3.9.16\bin\mvn.cmd" -version
```

## 5. Create Python Environment For ChromaDB

If you already created a broken `.venv`, remove it first:

```powershell
Remove-Item -Recurse -Force .\.venv
```

If it says `.venv` does not exist, ignore that and continue.

Create the environment with Python 3.11:

```powershell
py -3.11 -m venv .venv
```

Install ChromaDB:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
```

```powershell
.\.venv\Scripts\python.exe -m pip install chromadb==0.5.15
```

## 6. Start ChromaDB

Use PowerShell window 1:

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
```

```powershell
.\.venv\Scripts\chroma.exe run --path .\chroma_db --host 127.0.0.1 --port 8000
```

Keep this window open.

Check ChromaDB from another PowerShell window:

```powershell
Invoke-WebRequest http://127.0.0.1:8000/api/v1/heartbeat
```

## 7. Install Ollama For No-API-Key Mode

Run:

```powershell
winget install Ollama.Ollama
```

Close PowerShell, reopen it, then pull the models:

```powershell
ollama pull llama3
```

```powershell
ollama pull nomic-embed-text
```

Verify:

```powershell
ollama list
```

## 8. Start The Java App

Use PowerShell window 2:

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
```

```powershell
& ".\.tools\apache-maven-3.9.16\bin\mvn.cmd" -s ".\maven-settings.xml" spring-boot:run
```

When Spring Boot finishes starting, open:

```text
http://localhost:8080
```

## 9. Use The App Without OpenAI

In the browser:

1. Select `Ollama: llama3` in the Model provider dropdown.
2. Do not enter an OpenAI key.
3. Upload a PDF.
4. Click `Process PDFs`.
5. Ask questions from the uploaded PDF.

## Future Runs

PowerShell window 1:

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
.\.venv\Scripts\chroma.exe run --path .\chroma_db --host 127.0.0.1 --port 8000
```

PowerShell window 2:

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
& ".\.tools\apache-maven-3.9.16\bin\mvn.cmd" -s ".\maven-settings.xml" spring-boot:run
```

Browser:

```text
http://localhost:8080
```

## Reset The Vector Database

Stop the ChromaDB PowerShell window with `Ctrl + C`, then run:

```powershell
cd "C:\Users\supri_ak\OneDrive\Desktop\pdf chat project\Supriya\Supriya"
Remove-Item -Recurse -Force .\chroma_db
```

Then start ChromaDB again.

## Troubleshooting

If the app says ChromaDB is not reachable, make sure this command is running in another PowerShell window:

```powershell
.\.venv\Scripts\chroma.exe run --path .\chroma_db --host 127.0.0.1 --port 8000
```

If `mvn` is not recognized, use the local Maven command:

```powershell
& ".\.tools\apache-maven-3.9.16\bin\mvn.cmd" -s ".\maven-settings.xml" spring-boot:run
```

If ChromaDB installation fails with `Microsoft Visual C++ 14.0 or greater is required`, you are probably using Python 3.13. Use Python 3.11:

```powershell
py -3.11 -m venv .venv
```
