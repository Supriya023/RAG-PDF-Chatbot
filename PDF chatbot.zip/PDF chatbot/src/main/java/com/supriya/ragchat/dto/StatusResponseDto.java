package com.supriya.ragchat.dto;

public record StatusResponseDto(
        boolean chromaReachable,
        String collectionName,
        int indexedChunks,
        String message
) {
}
