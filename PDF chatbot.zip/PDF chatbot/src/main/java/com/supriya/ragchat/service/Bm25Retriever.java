package com.supriya.ragchat.service;

import com.supriya.ragchat.model.DocumentChunk;
import com.supriya.ragchat.model.SearchResult;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

@Component
public class Bm25Retriever {

    private static final Pattern TOKEN_SPLIT = Pattern.compile("[^a-zA-Z0-9]+");
    private static final double K1 = 1.5;
    private static final double B = 0.75;

    public List<SearchResult> search(String query, List<DocumentChunk> corpus, int topK) {
        if (query == null || query.isBlank() || corpus.isEmpty()) {
            return List.of();
        }

        List<String> queryTerms = tokenize(query);
        if (queryTerms.isEmpty()) {
            return List.of();
        }

        List<Map<String, Integer>> termFrequencies = new ArrayList<>();
        Map<String, Integer> documentFrequencies = new HashMap<>();
        int totalTerms = 0;

        for (DocumentChunk chunk : corpus) {
            List<String> terms = tokenize(chunk.text());
            totalTerms += terms.size();
            Map<String, Integer> tf = new HashMap<>();
            for (String term : terms) {
                tf.merge(term, 1, Integer::sum);
            }
            termFrequencies.add(tf);
            Set<String> uniqueTerms = new HashSet<>(tf.keySet());
            for (String term : uniqueTerms) {
                documentFrequencies.merge(term, 1, Integer::sum);
            }
        }

        double avgDocLength = corpus.isEmpty() ? 0.0 : (double) totalTerms / corpus.size();
        List<SearchResult> results = new ArrayList<>();
        for (int i = 0; i < corpus.size(); i++) {
            Map<String, Integer> tf = termFrequencies.get(i);
            int docLength = tf.values().stream().mapToInt(Integer::intValue).sum();
            double score = scoreDocument(queryTerms, tf, documentFrequencies, corpus.size(), docLength, avgDocLength);
            if (score > 0.0) {
                results.add(new SearchResult(corpus.get(i), score, "bm25"));
            }
        }

        double maxScore = results.stream().mapToDouble(SearchResult::score).max().orElse(1.0);
        return results.stream()
                .map(result -> new SearchResult(result.chunk(), result.score() / maxScore, result.retrievalType()))
                .sorted(Comparator.comparingDouble(SearchResult::score).reversed())
                .limit(topK)
                .toList();
    }

    private double scoreDocument(List<String> queryTerms,
                                 Map<String, Integer> tf,
                                 Map<String, Integer> df,
                                 int totalDocuments,
                                 int docLength,
                                 double avgDocLength) {
        double score = 0.0;
        for (String term : queryTerms) {
            int frequency = tf.getOrDefault(term, 0);
            if (frequency == 0) {
                continue;
            }
            int docsWithTerm = df.getOrDefault(term, 0);
            double idf = Math.log(1.0 + (totalDocuments - docsWithTerm + 0.5) / (docsWithTerm + 0.5));
            double denominator = frequency + K1 * (1.0 - B + B * docLength / Math.max(1.0, avgDocLength));
            score += idf * (frequency * (K1 + 1.0)) / denominator;
        }
        return score;
    }

    private List<String> tokenize(String text) {
        String[] rawTerms = TOKEN_SPLIT.split(text.toLowerCase(Locale.ROOT));
        List<String> terms = new ArrayList<>();
        for (String term : rawTerms) {
            if (term.length() >= 2 && term.length() <= 40) {
                terms.add(term);
            }
        }
        return terms;
    }
}
