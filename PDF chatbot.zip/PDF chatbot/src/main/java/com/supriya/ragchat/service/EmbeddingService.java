package com.supriya.ragchat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.supriya.ragchat.config.RagProperties;
import com.supriya.ragchat.model.Provider;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class EmbeddingService {

    private final RagProperties properties;
    private final RestClient restClient;

    public EmbeddingService(RagProperties properties, RestClient.Builder builder) {
        this.properties = properties;
        this.restClient = builder.build();
    }

    public List<List<Double>> embed(List<String> texts, Provider provider, String apiKey) {
        if (texts == null || texts.isEmpty()) {
            return List.of();
        }
        return switch (provider) {
            case OPENAI -> embedWithOpenAi(texts, apiKey);
            case OLLAMA -> embedWithOllama(texts);
        };
    }

    private List<List<Double>> embedWithOpenAi(List<String> texts, String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalArgumentException("OpenAI API key is required for OpenAI embeddings.");
        }

        JsonNode response = restClient.post()
                .uri(properties.getOpenaiBaseUrl() + "/embeddings")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey.trim())
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "model", properties.getOpenaiEmbeddingModel(),
                        "input", texts
                ))
                .retrieve()
                .body(JsonNode.class);

        if (response == null || !response.has("data")) {
            throw new IllegalStateException("OpenAI embeddings response was empty.");
        }

        List<List<Double>> embeddings = new ArrayList<>();
        for (JsonNode item : response.get("data")) {
            embeddings.add(toDoubleList(item.get("embedding")));
        }
        return embeddings;
    }

    private List<List<Double>> embedWithOllama(List<String> texts) {
        JsonNode response = restClient.post()
                .uri(properties.getOllamaBaseUrl() + "/api/embed")
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "model", properties.getOllamaEmbeddingModel(),
                        "input", texts
                ))
                .retrieve()
                .body(JsonNode.class);

        if (response == null || !response.has("embeddings")) {
            throw new IllegalStateException("Ollama embeddings response was empty. Run: ollama pull "
                    + properties.getOllamaEmbeddingModel());
        }

        List<List<Double>> embeddings = new ArrayList<>();
        for (JsonNode item : response.get("embeddings")) {
            embeddings.add(toDoubleList(item));
        }
        return embeddings;
    }

    private List<Double> toDoubleList(JsonNode arrayNode) {
        if (arrayNode == null || !arrayNode.isArray()) {
            throw new IllegalStateException("Embedding payload did not contain a numeric array.");
        }
        List<Double> vector = new ArrayList<>(arrayNode.size());
        for (JsonNode value : arrayNode) {
            vector.add(value.asDouble());
        }
        return vector;
    }
}
