package com.supriya.ragchat.dto;

public record SourceDto(
        String filename,
        int page,
        int chunkIndex,
        String preview,
        double score,
        String retrievalType
) {
}
