package com.supriya.ragchat.model;

public record ChatTurn(String userMessage, String assistantMessage) {
}
