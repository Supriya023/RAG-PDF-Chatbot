package com.supriya.ragchat.service;

import com.supriya.ragchat.config.RagProperties;
import com.supriya.ragchat.model.DocumentChunk;
import com.supriya.ragchat.model.Provider;
import com.supriya.ragchat.model.SearchResult;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class HybridRetrievalService {

    private static final double DENSE_WEIGHT = 0.70;
    private static final double BM25_WEIGHT = 0.30;

    private final RagProperties properties;
    private final ChromaClientService chromaClientService;
    private final EmbeddingService embeddingService;
    private final Bm25Retriever bm25Retriever;

    public HybridRetrievalService(RagProperties properties,
                                  ChromaClientService chromaClientService,
                                  EmbeddingService embeddingService,
                                  Bm25Retriever bm25Retriever) {
        this.properties = properties;
        this.chromaClientService = chromaClientService;
        this.embeddingService = embeddingService;
        this.bm25Retriever = bm25Retriever;
    }

    public List<SearchResult> retrieve(String query, Provider provider, String apiKey) {
        int topK = properties.getRetrievalTopK();
        List<Double> queryEmbedding = embeddingService.embed(List.of(query), provider, apiKey).get(0);
        List<SearchResult> denseResults = chromaClientService.denseSearch(provider, queryEmbedding, topK * 2);
        List<DocumentChunk> corpus = chromaClientService.getAllChunks(provider);
        List<SearchResult> bm25Results = bm25Retriever.search(query, corpus, topK * 2);

        Map<String, WeightedResult> combined = new LinkedHashMap<>();
        for (SearchResult result : denseResults) {
            combined.computeIfAbsent(result.chunk().id(), ignored -> new WeightedResult(result.chunk()))
                    .add(result.score() * DENSE_WEIGHT, "dense");
        }
        for (SearchResult result : bm25Results) {
            combined.computeIfAbsent(result.chunk().id(), ignored -> new WeightedResult(result.chunk()))
                    .add(result.score() * BM25_WEIGHT, "bm25");
        }

        return combined.values().stream()
                .map(WeightedResult::toSearchResult)
                .sorted(Comparator.comparingDouble(SearchResult::score).reversed())
                .limit(topK)
                .toList();
    }

    private static class WeightedResult {
        private final DocumentChunk chunk;
        private double score;
        private String type = "";

        private WeightedResult(DocumentChunk chunk) {
            this.chunk = chunk;
        }

        private void add(double score, String type) {
            this.score += score;
            if (this.type.isBlank()) {
                this.type = type;
            } else if (!this.type.contains(type)) {
                this.type += "+" + type;
            }
        }

        private SearchResult toSearchResult() {
            return new SearchResult(chunk, score, type);
        }
    }
}
