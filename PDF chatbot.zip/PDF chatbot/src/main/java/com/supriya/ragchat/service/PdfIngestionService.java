package com.supriya.ragchat.service;

import com.supriya.ragchat.config.RagProperties;
import com.supriya.ragchat.model.DocumentChunk;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;

@Service
public class PdfIngestionService {

    private static final int APPROX_CHARS_PER_TOKEN = 4;

    private final RagProperties properties;

    public PdfIngestionService(RagProperties properties) {
        this.properties = properties;
    }

    public ParsedPdf parse(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Uploaded PDF is empty.");
        }
        String filename = sanitizeFilename(file.getOriginalFilename());
        if (!filename.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            throw new IllegalArgumentException(filename + " is not a PDF file.");
        }

        List<DocumentChunk> chunks = new ArrayList<>();
        int pagesProcessed = 0;

        try (PDDocument document = PDDocument.load(file.getInputStream())) {
            PDFTextStripper stripper = new PDFTextStripper();
            int totalPages = document.getNumberOfPages();
            for (int page = 1; page <= totalPages; page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                String pageText = normalizeWhitespace(stripper.getText(document));
                if (pageText.isBlank()) {
                    continue;
                }
                pagesProcessed++;
                List<String> pageChunks = splitRecursively(pageText);
                for (int i = 0; i < pageChunks.size(); i++) {
                    String chunkText = pageChunks.get(i);
                    String hash = sha256(filename + "|" + page + "|" + i + "|" + chunkText);
                    String id = filename.replaceAll("[^a-zA-Z0-9._-]", "_") + "_p" + page + "_c" + i + "_" + hash.substring(0, 12);
                    chunks.add(new DocumentChunk(id, chunkText, filename, page, i, hash));
                }
            }
        } catch (IOException exception) {
            throw new IllegalArgumentException("Could not read PDF: " + filename, exception);
        }

        return new ParsedPdf(filename, pagesProcessed, chunks);
    }

    private List<String> splitRecursively(String text) {
        int chunkChars = Math.max(500, properties.getChunkTokenSize() * APPROX_CHARS_PER_TOKEN);
        int overlapChars = Math.max(0, properties.getChunkTokenOverlap() * APPROX_CHARS_PER_TOKEN);
        if (text.length() <= chunkChars) {
            return List.of(text);
        }

        List<String> chunks = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int targetEnd = Math.min(text.length(), start + chunkChars);
            int end = findNaturalBoundary(text, start, targetEnd);
            String chunk = text.substring(start, end).trim();
            if (!chunk.isBlank()) {
                chunks.add(chunk);
            }
            if (end >= text.length()) {
                break;
            }
            int nextStart = Math.max(0, end - overlapChars);
            if (nextStart <= start) {
                nextStart = end;
            }
            start = nextStart;
        }
        return chunks;
    }

    private int findNaturalBoundary(String text, int start, int targetEnd) {
        int minEnd = Math.min(text.length(), start + 500);
        String[] separators = {"\n\n", ". ", "? ", "! ", "; ", ", ", " "};
        for (String separator : separators) {
            int idx = text.lastIndexOf(separator, targetEnd);
            if (idx >= minEnd) {
                return Math.min(text.length(), idx + separator.length());
            }
        }
        return targetEnd;
    }

    private String sanitizeFilename(String filename) {
        if (filename == null || filename.isBlank()) {
            return "uploaded.pdf";
        }
        return filename.replace("\\", "/").substring(filename.replace("\\", "/").lastIndexOf("/") + 1);
    }

    private String normalizeWhitespace(String text) {
        return text == null ? "" : text.replace('\u0000', ' ')
                .replaceAll("[ \\t\\x0B\\f\\r]+", " ")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();
    }

    private String sha256(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(text.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(bytes);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available.", exception);
        }
    }

    public record ParsedPdf(String filename, int pagesProcessed, List<DocumentChunk> chunks) {
    }
}
