package com.supriya.ragchat.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "rag")
public class RagProperties {

    private String chromaBaseUrl;
    private String collectionPrefix;
    private String openaiBaseUrl;
    private String openaiChatModel;
    private String openaiEmbeddingModel;
    private String ollamaBaseUrl;
    private String ollamaChatModel;
    private String ollamaEmbeddingModel;
    private int chunkTokenSize;
    private int chunkTokenOverlap;
    private int retrievalTopK;

    public String getChromaBaseUrl() {
        return chromaBaseUrl;
    }

    public void setChromaBaseUrl(String chromaBaseUrl) {
        this.chromaBaseUrl = chromaBaseUrl;
    }

    public String getCollectionPrefix() {
        return collectionPrefix;
    }

    public void setCollectionPrefix(String collectionPrefix) {
        this.collectionPrefix = collectionPrefix;
    }

    public String getOpenaiBaseUrl() {
        return openaiBaseUrl;
    }

    public void setOpenaiBaseUrl(String openaiBaseUrl) {
        this.openaiBaseUrl = openaiBaseUrl;
    }

    public String getOpenaiChatModel() {
        return openaiChatModel;
    }

    public void setOpenaiChatModel(String openaiChatModel) {
        this.openaiChatModel = openaiChatModel;
    }

    public String getOpenaiEmbeddingModel() {
        return openaiEmbeddingModel;
    }

    public void setOpenaiEmbeddingModel(String openaiEmbeddingModel) {
        this.openaiEmbeddingModel = openaiEmbeddingModel;
    }

    public String getOllamaBaseUrl() {
        return ollamaBaseUrl;
    }

    public void setOllamaBaseUrl(String ollamaBaseUrl) {
        this.ollamaBaseUrl = ollamaBaseUrl;
    }

    public String getOllamaChatModel() {
        return ollamaChatModel;
    }

    public void setOllamaChatModel(String ollamaChatModel) {
        this.ollamaChatModel = ollamaChatModel;
    }

    public String getOllamaEmbeddingModel() {
        return ollamaEmbeddingModel;
    }

    public void setOllamaEmbeddingModel(String ollamaEmbeddingModel) {
        this.ollamaEmbeddingModel = ollamaEmbeddingModel;
    }

    public int getChunkTokenSize() {
        return chunkTokenSize;
    }

    public void setChunkTokenSize(int chunkTokenSize) {
        this.chunkTokenSize = chunkTokenSize;
    }

    public int getChunkTokenOverlap() {
        return chunkTokenOverlap;
    }

    public void setChunkTokenOverlap(int chunkTokenOverlap) {
        this.chunkTokenOverlap = chunkTokenOverlap;
    }

    public int getRetrievalTopK() {
        return retrievalTopK;
    }

    public void setRetrievalTopK(int retrievalTopK) {
        this.retrievalTopK = retrievalTopK;
    }
}
