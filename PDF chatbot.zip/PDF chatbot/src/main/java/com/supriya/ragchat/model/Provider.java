package com.supriya.ragchat.model;

public enum Provider {
    OPENAI,
    OLLAMA;

    public static Provider from(String raw) {
        if (raw == null || raw.isBlank()) {
            return OPENAI;
        }
        return Provider.valueOf(raw.trim().toUpperCase());
    }

    public String collectionSuffix() {
        return name().toLowerCase();
    }
}
