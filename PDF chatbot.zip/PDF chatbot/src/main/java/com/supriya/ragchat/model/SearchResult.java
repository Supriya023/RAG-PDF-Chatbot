package com.supriya.ragchat.model;

public record SearchResult(
        DocumentChunk chunk,
        double score,
        String retrievalType
) {
}
