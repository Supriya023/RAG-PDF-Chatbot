package com.supriya.ragchat.dto;

import java.util.List;

public record ChatResponseDto(
        String answer,
        List<SourceDto> sources
) {
}
