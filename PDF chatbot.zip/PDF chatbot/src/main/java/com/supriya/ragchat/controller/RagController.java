package com.supriya.ragchat.controller;

import com.supriya.ragchat.dto.ChatRequestDto;
import com.supriya.ragchat.dto.ChatResponseDto;
import com.supriya.ragchat.dto.IngestResponseDto;
import com.supriya.ragchat.dto.ResetResponseDto;
import com.supriya.ragchat.dto.StatusResponseDto;
import com.supriya.ragchat.model.Provider;
import com.supriya.ragchat.service.RagPipelineService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class RagController {

    private final RagPipelineService ragPipelineService;

    public RagController(RagPipelineService ragPipelineService) {
        this.ragPipelineService = ragPipelineService;
    }

    @PostMapping(value = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public IngestResponseDto ingest(@RequestPart("files") MultipartFile[] files,
                                    @RequestParam(defaultValue = "openai") String provider,
                                    @RequestParam(required = false) String apiKey) {
        List<MultipartFile> uploadedFiles = files == null ? List.of() : Arrays.asList(files);
        return ragPipelineService.ingest(uploadedFiles, Provider.from(provider), apiKey);
    }

    @PostMapping("/chat")
    public ChatResponseDto chat(@Valid @RequestBody ChatRequestDto request) {
        return ragPipelineService.ask(
                request.message(),
                Provider.from(request.provider()),
                request.apiKey(),
                request.sessionId()
        );
    }

    @GetMapping("/status")
    public StatusResponseDto status(@RequestParam(defaultValue = "openai") String provider) {
        return ragPipelineService.status(Provider.from(provider));
    }

    @PostMapping("/reset")
    public ResetResponseDto reset(@RequestParam(defaultValue = "openai") String provider) {
        return ragPipelineService.reset(Provider.from(provider));
    }
}
