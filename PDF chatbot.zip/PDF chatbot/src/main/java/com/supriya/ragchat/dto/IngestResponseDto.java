package com.supriya.ragchat.dto;

public record IngestResponseDto(
        int filesProcessed,
        int pagesProcessed,
        int chunksIndexed,
        String collectionName,
        String message
) {
}
