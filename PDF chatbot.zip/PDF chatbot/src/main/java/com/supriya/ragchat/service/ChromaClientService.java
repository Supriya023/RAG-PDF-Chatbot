package com.supriya.ragchat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.supriya.ragchat.config.RagProperties;
import com.supriya.ragchat.model.DocumentChunk;
import com.supriya.ragchat.model.Provider;
import com.supriya.ragchat.model.SearchResult;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ChromaClientService {

    private static final String DEFAULT_TENANT = "default_tenant";
    private static final String DEFAULT_DATABASE = "default_database";
    private static final String CHROMA_START_COMMAND = "Cannot initialize Chroma collection. Start ChromaDB with: .\\.venv\\Scripts\\chroma.exe run --path .\\chroma_db --host 127.0.0.1 --port 8000";

    private final RagProperties properties;
    private final RestClient restClient;
    private final Map<String, String> collectionIdCache = new ConcurrentHashMap<>();

    public ChromaClientService(RagProperties properties, RestClient.Builder builder) {
        this.properties = properties;
        this.restClient = builder.build();
    }

    public String collectionName(Provider provider) {
        return properties.getCollectionPrefix() + "_" + provider.collectionSuffix();
    }

    public boolean isReachable() {
        try {
            restClient.get()
                    .uri(properties.getChromaBaseUrl() + "/api/v1/heartbeat")
                    .retrieve()
                    .body(String.class);
            return true;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public int count(Provider provider) {
        try {
            String collectionId = ensureCollection(provider);
            JsonNode response = restClient.get()
                    .uri(collectionOperationUrl(collectionId, "count"))
                    .retrieve()
                    .body(JsonNode.class);
            if (response == null) {
                return 0;
            }
            if (response.isNumber()) {
                return response.asInt();
            }
            return response.path("count").asInt(0);
        } catch (RuntimeException exception) {
            return 0;
        }
    }

    public void upsert(Provider provider, List<DocumentChunk> chunks, List<List<Double>> embeddings) {
        if (chunks.size() != embeddings.size()) {
            throw new IllegalArgumentException("Chunk count and embedding count must match.");
        }
        if (chunks.isEmpty()) {
            return;
        }

        String collectionId = ensureCollection(provider);
        List<String> ids = new ArrayList<>();
        List<String> documents = new ArrayList<>();
        List<Map<String, Object>> metadatas = new ArrayList<>();

        for (DocumentChunk chunk : chunks) {
            ids.add(chunk.id());
            documents.add(chunk.text());
            metadatas.add(Map.of(
                    "filename", chunk.filename(),
                    "page", chunk.page(),
                    "chunkIndex", chunk.chunkIndex(),
                    "contentHash", chunk.contentHash()
            ));
        }

        restClient.post()
                .uri(collectionOperationUrl(collectionId, "upsert"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "ids", ids,
                        "documents", documents,
                        "metadatas", metadatas,
                        "embeddings", embeddings
                ))
                .retrieve()
                .toBodilessEntity();
    }

    public List<SearchResult> denseSearch(Provider provider, List<Double> queryEmbedding, int topK) {
        String collectionId = ensureCollection(provider);
        JsonNode response = restClient.post()
                .uri(collectionOperationUrl(collectionId, "query"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "query_embeddings", List.of(queryEmbedding),
                        "n_results", topK,
                        "include", List.of("documents", "metadatas", "distances")
                ))
                .retrieve()
                .body(JsonNode.class);

        if (response == null) {
            return List.of();
        }

        JsonNode ids = response.at("/ids/0");
        JsonNode documents = response.at("/documents/0");
        JsonNode metadatas = response.at("/metadatas/0");
        JsonNode distances = response.at("/distances/0");
        if (!ids.isArray()) {
            return List.of();
        }

        List<SearchResult> results = new ArrayList<>();
        for (int i = 0; i < ids.size(); i++) {
            double distance = distances.isArray() && distances.size() > i ? distances.get(i).asDouble() : 1.0;
            double score = 1.0 / (1.0 + Math.max(0.0, distance));
            results.add(new SearchResult(toChunk(
                    ids.get(i).asText(),
                    documents.get(i).asText(),
                    metadatas.get(i)
            ), score, "dense"));
        }
        return results;
    }

    public List<DocumentChunk> getAllChunks(Provider provider) {
        String collectionId = ensureCollection(provider);
        JsonNode response = restClient.post()
                .uri(collectionOperationUrl(collectionId, "get"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of("include", List.of("documents", "metadatas")))
                .retrieve()
                .body(JsonNode.class);

        if (response == null || !response.has("ids")) {
            return List.of();
        }

        List<DocumentChunk> chunks = new ArrayList<>();
        JsonNode ids = response.get("ids");
        JsonNode documents = response.get("documents");
        JsonNode metadatas = response.get("metadatas");
        for (int i = 0; i < ids.size(); i++) {
            chunks.add(toChunk(ids.get(i).asText(), documents.get(i).asText(), metadatas.get(i)));
        }
        return chunks;
    }

    public void deleteCollection(Provider provider) {
        String name = collectionName(provider);
        try {
            restClient.delete()
                    .uri(collectionUrl(name))
                    .retrieve()
                    .toBodilessEntity();
        } catch (HttpClientErrorException.NotFound ignored) {
            // Reset is idempotent from the UI perspective.
        } finally {
            collectionIdCache.remove(name);
        }
    }

    private String ensureCollection(Provider provider) {
        String name = collectionName(provider);
        String cached = collectionIdCache.get(name);
        if (cached != null) {
            return cached;
        }

        try {
            String existingId = findCollectionIdByName(name);
            if (existingId != null) {
                collectionIdCache.put(name, existingId);
                return existingId;
            }

            JsonNode created = restClient.post()
                    .uri(collectionsUrl())
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of(
                            "name", name,
                            "metadata", Map.of("hnsw:space", "cosine"),
                            "get_or_create", true
                    ))
                    .retrieve()
                    .body(JsonNode.class);
            String id = created == null ? name : created.path("id").asText(name);
            collectionIdCache.put(name, id);
            return id;
        } catch (RuntimeException exception) {
            throw new IllegalStateException(CHROMA_START_COMMAND, exception);
        }
    }

    private String findCollectionIdByName(String name) {
        JsonNode collections = restClient.get()
                .uri(collectionsUrl())
                .retrieve()
                .body(JsonNode.class);

        if (collections == null || !collections.isArray()) {
            return null;
        }

        for (JsonNode collection : collections) {
            if (name.equals(collection.path("name").asText())) {
                return collection.path("id").asText(name);
            }
        }
        return null;
    }

    private String collectionsUrl() {
        return properties.getChromaBaseUrl()
                + "/api/v1/collections?tenant=" + DEFAULT_TENANT
                + "&database=" + DEFAULT_DATABASE;
    }

    private String collectionUrl(String collectionNameOrId) {
        return properties.getChromaBaseUrl()
                + "/api/v1/collections/" + collectionNameOrId
                + "?tenant=" + DEFAULT_TENANT
                + "&database=" + DEFAULT_DATABASE;
    }

    private String collectionOperationUrl(String collectionId, String operation) {
        return properties.getChromaBaseUrl()
                + "/api/v1/collections/" + collectionId + "/" + operation
                + "?tenant=" + DEFAULT_TENANT
                + "&database=" + DEFAULT_DATABASE;
    }

    private DocumentChunk toChunk(String id, String text, JsonNode metadata) {
        Map<String, JsonNode> fields = new LinkedHashMap<>();
        if (metadata != null && metadata.isObject()) {
            metadata.fields().forEachRemaining(entry -> fields.put(entry.getKey(), entry.getValue()));
        }
        String filename = fields.getOrDefault("filename", textNode("unknown.pdf")).asText();
        int page = fields.getOrDefault("page", intNode(0)).asInt();
        int chunkIndex = fields.getOrDefault("chunkIndex", intNode(0)).asInt();
        String contentHash = fields.getOrDefault("contentHash", textNode("")).asText();
        return new DocumentChunk(id, text, filename, page, chunkIndex, contentHash);
    }

    private JsonNode textNode(String value) {
        return com.fasterxml.jackson.databind.node.TextNode.valueOf(value);
    }

    private JsonNode intNode(int value) {
        return com.fasterxml.jackson.databind.node.IntNode.valueOf(value);
    }
}
