package com.supriya.ragchat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.supriya.ragchat.config.RagProperties;
import com.supriya.ragchat.model.Provider;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Service
public class ChatGenerationService {

    private final RagProperties properties;
    private final RestClient restClient;

    public ChatGenerationService(RagProperties properties, RestClient.Builder builder) {
        this.properties = properties;
        this.restClient = builder.build();
    }

    public String generate(Provider provider, String apiKey, String systemPrompt, String userPrompt) {
        return switch (provider) {
            case OPENAI -> generateWithOpenAi(apiKey, systemPrompt, userPrompt);
            case OLLAMA -> generateWithOllama(systemPrompt, userPrompt);
        };
    }

    private String generateWithOpenAi(String apiKey, String systemPrompt, String userPrompt) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalArgumentException("OpenAI API key is required for OpenAI chat.");
        }

        JsonNode response = restClient.post()
                .uri(properties.getOpenaiBaseUrl() + "/chat/completions")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey.trim())
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "model", properties.getOpenaiChatModel(),
                        "temperature", 0.1,
                        "messages", List.of(
                                Map.of("role", "system", "content", systemPrompt),
                                Map.of("role", "user", "content", userPrompt)
                        )
                ))
                .retrieve()
                .body(JsonNode.class);

        JsonNode content = response == null ? null : response.at("/choices/0/message/content");
        if (content == null || content.isMissingNode()) {
            throw new IllegalStateException("OpenAI chat response was empty.");
        }
        return content.asText();
    }

    private String generateWithOllama(String systemPrompt, String userPrompt) {
        JsonNode response = restClient.post()
                .uri(properties.getOllamaBaseUrl() + "/api/chat")
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of(
                        "model", properties.getOllamaChatModel(),
                        "stream", false,
                        "options", Map.of(
                                "temperature", 0.1,
                                "num_ctx", 8192
                        ),
                        "messages", List.of(
                                Map.of("role", "system", "content", systemPrompt),
                                Map.of("role", "user", "content", userPrompt)
                        ),
                        "keep_alive", "10m"
                ))
                .retrieve()
                .body(JsonNode.class);

        JsonNode content = response == null ? null : response.at("/message/content");
        if (content == null || content.isMissingNode()) {
            throw new IllegalStateException("Ollama chat response was empty. Run: ollama pull "
                    + properties.getOllamaChatModel());
        }
        return content.asText();
    }
}
