package com.supriya.ragchat.service;

import com.supriya.ragchat.dto.ChatResponseDto;
import com.supriya.ragchat.dto.IngestResponseDto;
import com.supriya.ragchat.dto.ResetResponseDto;
import com.supriya.ragchat.dto.SourceDto;
import com.supriya.ragchat.dto.StatusResponseDto;
import com.supriya.ragchat.model.ChatTurn;
import com.supriya.ragchat.model.DocumentChunk;
import com.supriya.ragchat.model.Provider;
import com.supriya.ragchat.model.SearchResult;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RagPipelineService {

    private static final String FALLBACK_ANSWER = "I cannot find the answer in the provided documents.";
    private static final String CHROMA_START_COMMAND = "ChromaDB is not reachable. Start it with: .\\.venv\\Scripts\\chroma.exe run --path .\\chroma_db --host 127.0.0.1 --port 8000";
    private static final int EMBEDDING_BATCH_SIZE = 64;
    private static final int MAX_HISTORY_TURNS = 8;

    private final PdfIngestionService pdfIngestionService;
    private final EmbeddingService embeddingService;
    private final ChromaClientService chromaClientService;
    private final HybridRetrievalService hybridRetrievalService;
    private final ChatGenerationService chatGenerationService;
    private final Map<String, List<ChatTurn>> chatHistoryBySession = new ConcurrentHashMap<>();

    public RagPipelineService(PdfIngestionService pdfIngestionService,
                              EmbeddingService embeddingService,
                              ChromaClientService chromaClientService,
                              HybridRetrievalService hybridRetrievalService,
                              ChatGenerationService chatGenerationService) {
        this.pdfIngestionService = pdfIngestionService;
        this.embeddingService = embeddingService;
        this.chromaClientService = chromaClientService;
        this.hybridRetrievalService = hybridRetrievalService;
        this.chatGenerationService = chatGenerationService;
    }

    public IngestResponseDto ingest(List<MultipartFile> files, Provider provider, String apiKey) {
        if (files == null || files.isEmpty()) {
            throw new IllegalArgumentException("Upload at least one PDF file.");
        }
        if (!chromaClientService.isReachable()) {
            throw new IllegalStateException(CHROMA_START_COMMAND);
        }

        List<DocumentChunk> allChunks = new ArrayList<>();
        int pagesProcessed = 0;
        int filesProcessed = 0;
        for (MultipartFile file : files) {
            PdfIngestionService.ParsedPdf parsed = pdfIngestionService.parse(file);
            if (!parsed.chunks().isEmpty()) {
                allChunks.addAll(parsed.chunks());
                pagesProcessed += parsed.pagesProcessed();
                filesProcessed++;
            }
        }

        if (allChunks.isEmpty()) {
            throw new IllegalArgumentException("No extractable text was found in the uploaded PDF files.");
        }

        for (int start = 0; start < allChunks.size(); start += EMBEDDING_BATCH_SIZE) {
            int end = Math.min(allChunks.size(), start + EMBEDDING_BATCH_SIZE);
            List<DocumentChunk> batch = allChunks.subList(start, end);
            List<String> texts = batch.stream().map(DocumentChunk::text).toList();
            List<List<Double>> embeddings = embeddingService.embed(texts, provider, apiKey);
            chromaClientService.upsert(provider, batch, embeddings);
        }

        return new IngestResponseDto(
                filesProcessed,
                pagesProcessed,
                allChunks.size(),
                chromaClientService.collectionName(provider),
                "Documents indexed successfully."
        );
    }

    public ChatResponseDto ask(String message, Provider provider, String apiKey, String sessionId) {
        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("Question cannot be empty.");
        }
        if (!chromaClientService.isReachable()) {
            throw new IllegalStateException(CHROMA_START_COMMAND);
        }
        if (chromaClientService.count(provider) == 0) {
            return new ChatResponseDto("Upload and process PDFs before asking questions.", List.of());
        }

        String normalizedSessionId = normalizeSessionId(sessionId);
        List<ChatTurn> history = chatHistoryBySession.getOrDefault(normalizedSessionId, List.of());
        String retrievalQuery = buildHistoryAwareQuery(history, message);
        List<SearchResult> results = hybridRetrievalService.retrieve(retrievalQuery, provider, apiKey);

        if (results.isEmpty()) {
            remember(normalizedSessionId, message, FALLBACK_ANSWER);
            return new ChatResponseDto(FALLBACK_ANSWER, List.of());
        }

        String systemPrompt = """
                You are a careful academic PDF question-answering assistant.
                Use only the provided document context to answer the user.
                If the answer cannot be found in the context, reply exactly:
                "I cannot find the answer in the provided documents."
                Do not use outside knowledge. Do not invent names, numbers, formulas, dates, or citations.
                Keep answers clear and concise for an engineering student.
                """;

        String userPrompt = buildUserPrompt(history, message, results);
        String answer = chatGenerationService.generate(provider, apiKey, systemPrompt, userPrompt).trim();
        if (answer.isBlank()) {
            answer = FALLBACK_ANSWER;
        }

        remember(normalizedSessionId, message, answer);
        return new ChatResponseDto(answer, toSources(results));
    }

    public StatusResponseDto status(Provider provider) {
        boolean reachable = chromaClientService.isReachable();
        int count = reachable ? chromaClientService.count(provider) : 0;
        return new StatusResponseDto(
                reachable,
                chromaClientService.collectionName(provider),
                count,
                reachable ? "ChromaDB is reachable." : "ChromaDB is not reachable."
        );
    }

    public ResetResponseDto reset(Provider provider) {
        if (!chromaClientService.isReachable()) {
            throw new IllegalStateException(CHROMA_START_COMMAND);
        }
        chromaClientService.deleteCollection(provider);
        chatHistoryBySession.clear();
        return new ResetResponseDto(chromaClientService.collectionName(provider), "Database and chat memory reset.");
    }

    private String buildHistoryAwareQuery(List<ChatTurn> history, String message) {
        if (history.isEmpty()) {
            return message;
        }
        StringBuilder builder = new StringBuilder();
        history.stream()
                .skip(Math.max(0, history.size() - 3))
                .forEach(turn -> builder.append("Previous question: ")
                        .append(turn.userMessage())
                        .append("\nPrevious answer: ")
                        .append(turn.assistantMessage())
                        .append("\n"));
        builder.append("Current question: ").append(message);
        return builder.toString();
    }

    private String buildUserPrompt(List<ChatTurn> history, String message, List<SearchResult> results) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Conversation history:\n");
        if (history.isEmpty()) {
            prompt.append("(none)\n");
        } else {
            history.stream()
                    .skip(Math.max(0, history.size() - MAX_HISTORY_TURNS))
                    .forEach(turn -> prompt.append("User: ").append(turn.userMessage()).append("\n")
                            .append("Assistant: ").append(turn.assistantMessage()).append("\n"));
        }

        prompt.append("\nRetrieved document context:\n");
        for (int i = 0; i < results.size(); i++) {
            DocumentChunk chunk = results.get(i).chunk();
            prompt.append("\n[Source ").append(i + 1)
                    .append(": ").append(chunk.filename())
                    .append(", page ").append(chunk.page())
                    .append(", chunk ").append(chunk.chunkIndex())
                    .append("]\n")
                    .append(chunk.text())
                    .append("\n");
        }
        prompt.append("\nUser question: ").append(message);
        return prompt.toString();
    }

    private List<SourceDto> toSources(List<SearchResult> results) {
        return results.stream()
                .sorted(Comparator.comparingDouble(SearchResult::score).reversed())
                .map(result -> new SourceDto(
                        result.chunk().filename(),
                        result.chunk().page(),
                        result.chunk().chunkIndex(),
                        preview(result.chunk().text()),
                        Math.round(result.score() * 1000.0) / 1000.0,
                        result.retrievalType()
                ))
                .toList();
    }

    private String preview(String text) {
        String cleaned = text.replaceAll("\\s+", " ").trim();
        return cleaned.length() <= 280 ? cleaned : cleaned.substring(0, 280) + "...";
    }

    private void remember(String sessionId, String userMessage, String assistantMessage) {
        chatHistoryBySession.compute(sessionId, (ignored, existing) -> {
            List<ChatTurn> updated = existing == null ? new ArrayList<>() : new ArrayList<>(existing);
            updated.add(new ChatTurn(userMessage, assistantMessage));
            if (updated.size() > MAX_HISTORY_TURNS) {
                return new ArrayList<>(updated.subList(updated.size() - MAX_HISTORY_TURNS, updated.size()));
            }
            return updated;
        });
    }

    private String normalizeSessionId(String sessionId) {
        return sessionId == null || sessionId.isBlank() ? "default" : sessionId.trim();
    }
}
