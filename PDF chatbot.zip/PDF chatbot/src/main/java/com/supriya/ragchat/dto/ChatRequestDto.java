package com.supriya.ragchat.dto;

import jakarta.validation.constraints.NotBlank;

public record ChatRequestDto(
        @NotBlank String message,
        String provider,
        String apiKey,
        String sessionId
) {
}
