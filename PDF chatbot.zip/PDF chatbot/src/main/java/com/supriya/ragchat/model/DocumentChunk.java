package com.supriya.ragchat.model;

public record DocumentChunk(
        String id,
        String text,
        String filename,
        int page,
        int chunkIndex,
        String contentHash
) {
}
