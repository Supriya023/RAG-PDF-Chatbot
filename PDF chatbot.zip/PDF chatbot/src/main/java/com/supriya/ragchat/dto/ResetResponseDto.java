package com.supriya.ragchat.dto;

public record ResetResponseDto(String collectionName, String message) {
}
